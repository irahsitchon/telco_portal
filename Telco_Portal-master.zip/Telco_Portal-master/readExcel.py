import openpyxl

wk = openpyxl.load_workbook("/Users/irah/Documents/phonumbers.xlsx")

print(wk.sheetnames)
